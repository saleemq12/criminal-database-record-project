<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "CRIMINAL_RECORD_DB";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>

</head>
<body>

<h1 align="center">Criminal record update</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>Criminal ID</th>
<th>first name</th>
<th>last name</th>
<th>phone number</th>
<th>City</th>
<th>house no</th>
<th>street no</th>
<th>gender</th>
<th>date of birth</th>
<th>birth mark</th>
<th>height</th>

</tr>
<?php
$sql = "SELECT * FROM criminal";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

 <td> <?php  echo $row['criminal_id'];?></td>
<td> <?php  echo $row['Fname'];?></td>
<td> <?php  echo $row['Lname'];?></td>
<td> <?php  echo $row['Ph_no'];?></td>
<td> <?php  echo $row['city'];?></td>
<td> <?php  echo $row['house_no'];?></td>
<td> <?php  echo $row['street_no'];?></td>
<td> <?php  echo $row['Gender'];?></td>
<td> <?php  echo $row['Dob'];?></td>
<td> <?php  echo $row['birth_mark'];?></td>
<td> <?php  echo $row['height'];?></td>

 <td><a href="edit.php?edit_id=<?php echo $row['criminal_id']; ?>" alt="edit" >Edit/update</a></td>
 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
<h1 align="center">Crime record update</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>Crime ID</th>
<th>Crime Name</th>
<th>Category</th>
<th>Crime Location</th>
</tr>
<?php
$sql = "SELECT * FROM Crime";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

 <td> <?php  echo $row['Crime_id'];?></td>
<td> <?php  echo $row['crime_name'];?></td>
<td> <?php  echo $row['Category'];?></td>
<td> <?php  echo $row['Crime_location'];?></td>
 <td><a href="editcrime.php?edit_id=<?php echo $row['Crime_id']; ?>" alt="edit" >Edit/update</a></td>
 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
<h1 align="center">punishment record update</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>punishment id</th>
<th>punishment type</th>
<th>Court status</th>
</tr>
<?php
$sql = "SELECT * FROM  Punishment";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

 <td> <?php  echo $row['Punishment_id'];?></td>
<td> <?php  echo $row['P_Type'];?></td>
<td> <?php  echo $row['court_status'];?></td>
 <td><a href="editpunishment.php?edit_id=<?php echo $row['Punishment_id']; ?>" alt="edit" >Edit/update</a></td>
 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
<h1 align="center">Court record update</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>Court_id</th>
<th>Court_type</th>
<th>judge_id</th>
<th>judge_name</th>
<th>C_address</th>
</tr>
<?php
$sql = "SELECT * FROM court_status";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['Court_id'];?></td>
<td> <?php  echo $row['Court_type'];?></td>
<td> <?php  echo $row['judge_id'];?></td>
<td> <?php  echo $row['judge_name'];?></td>
<td> <?php  echo $row['C_address'];?></td>
 <td><a href="editcourt.php?edit_id=<?php echo $row['Court_id']; ?>" alt="edit" >Edit/update</a></td>
 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>

<h1 align="center">Police Station record update</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>Police station id</th>
<th>police station name</th>
<th>police station address</th>
<th>landline</th>
</tr>
<?php
$sql = "SELECT * FROM Dealing_Police_Station";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

 <td> <?php  echo $row['Ps_id'];?></td>
<td> <?php  echo $row['Ps_name'];?></td>
<td> <?php  echo $row['Ps_address'];?></td>
<td> <?php  echo $row['Landline'];?></td>
 <td><a href="editps.php?edit_id=<?php echo $row['Ps_id']; ?>" alt="edit" >Edit/update</a></td>
 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
<h1 align="center">Investigation Officer record update</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>Officer Id</th>
<th>First Name</th>
<th>Last Name</th>
<th>Officer Rank</th>
<th>Phone Number</th>
</tr>
<?php
$sql = "SELECT * FROM Investigation_officer";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

 <td> <?php  echo $row['officer_id'];?></td>
<td> <?php  echo $row['Fname'];?></td>
<td> <?php  echo $row['Lname'];?></td>
<td> <?php  echo $row['Officer_rank'];?></td>
<td> <?php  echo $row['ph_no'];?></td>
 <td><a href="editofficer.php?edit_id=<?php echo $row['officer_id']; ?>" alt="edit" >Edit/update</a></td>
 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
<h1 align="center">Prison record update</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>prison id</th>
<th>prison name</th>
<th>prison address</th>
<th>landline</th>
</tr>
<?php
$sql = "SELECT * FROM prison";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

 <td> <?php  echo $row['Prison_id'];?></td>
<td> <?php  echo $row['Prison_name'];?></td>
<td> <?php  echo $row['P_address'];?></td>
<td> <?php  echo $row['Landline'];?></td>
 <td><a href="editprison.php?edit_id=<?php echo $row['Prison_id']; ?>" alt="edit" >Edit/update</a></td>
 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>