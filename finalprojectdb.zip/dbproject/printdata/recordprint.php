<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "CRIMINAL_RECORD_DB";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>

</head>
<body>

<h1 align="center">*************Criminal information **********</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>Criminal ID</th>
<th>FIRST NAME</th>
<th>LAST NAME</th>
<th>PHONE NO</th>
<th>city</th>
<th>house number</th>
<th>street number</th>
<th>gender</th>
<th>DOB</th>
<th>Birthmark</th>
<th>Height</th>
<th>police station id</th>
<th>prison id</th>


</tr>
<?php
$sql = "SELECT * FROM criminal";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['criminal_id'];?></td>
<td> <?php  echo $row['Fname'];?></td>
<td> <?php  echo $row['Lname'];?></td>
<td> <?php  echo $row['Ph_no'];?></td>
<td> <?php  echo $row['city'];?></td>
<td> <?php  echo $row['house_no'];?></td>
<td> <?php  echo $row['street_no'];?></td>
<td> <?php  echo $row['Gender'];?></td>
<td> <?php  echo $row['Dob'];?></td>
<td> <?php  echo $row['birth_mark'];?></td>
<td> <?php  echo $row['height'];?></td>
<td> <?php  echo $row['ps_id'];?></td>
<td> <?php  echo $row['prison_id'];?></td>
 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>

<h1 align="center">*************Crime information **********</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>crime id</th>
<th>crime name</th>
<th>category</th>
<th>crime location</th>
<th>punishment id</th>
</tr>
<?php
$sql = "SELECT * FROM crime";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['Crime_id'];?></td>
<td> <?php  echo $row['crime_name'];?></td>
<td> <?php  echo $row['Category'];?></td>
<td> <?php  echo $row['Crime_location'];?></td>
<td> <?php  echo $row['punishment_id'];?></td>
 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
<h1 align="center">*************Court status information **********</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>court ID</th>
<th>court type</th>
<th>judge id</th>
<th>judge name</th>
<th>court address</th>
</tr>
<?php
$sql = "SELECT * FROM court_status";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['Court_id'];?></td>
<td> <?php  echo $row['Court_type'];?></td>
<td> <?php  echo $row['judge_id'];?></td>
<td> <?php  echo $row['judge_name'];?></td>
<td> <?php  echo $row['C_address'];?></td>
 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
<h1 align="center">*************Punishment**********</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>Punishment ID</th>
<th>Punishment Type</th>
<th>Court Status</th>
</tr>
<?php
$sql = "SELECT * FROM Punishment";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['Punishment_id'];?></td>
<td> <?php  echo $row['P_Type'];?></td>
<td> <?php  echo $row['court_status'];?></td>
 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
<h1 align="center">*************Dealing Police Station Info**********</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>Police station id</th>
<th>Police station Name</th>
<th>Police station address</th>
<th>Landline</th>
</tr>
<?php
$sql = "SELECT * FROM Dealing_Police_Station";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['Ps_id'];?></td>
<td> <?php  echo $row['Ps_name'];?></td>
<td> <?php  echo $row['Ps_address'];?></td>
<td> <?php  echo $row['Landline'];?></td>
 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
<h1 align="center">*************Investigation Officer Information**********</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>officer id</th>
<th>First name </th>
<th>Last name</th>
<th>officer rank</th>
<th>phone number</th>
</tr>
<?php
$sql = "SELECT * FROM Investigation_officer";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['officer_id'];?></td>
<td> <?php  echo $row['Fname'];?></td>
<td> <?php  echo $row['Lname'];?></td>
<td> <?php  echo $row['Officer_rank'];?></td>
<td> <?php  echo $row['ph_no'];?></td>
 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
<h1 align="center">*************Prison Information**********</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>Prison id</th>
<th> Prison Name</th>
<th>Prison Address</th>
<th>Landline</th>
</tr>
<?php
$sql = "SELECT * FROM prison";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['Prison_id'];?></td>
<td> <?php  echo $row['Prison_name'];?></td>
<td> <?php  echo $row['P_address'];?></td>
<td> <?php  echo $row['Landline'];?></td>
 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>