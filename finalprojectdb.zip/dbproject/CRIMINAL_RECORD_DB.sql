SHOW DATABASES;
show databases;
create database CRIMINAL_RECORD_DB;
use CRIMINAL_RECORD_DB;
show tables;
create table Criminal(
   criminal_id int(10),
   Lname varchar(50),
   Fname varchar(50),
   Dob date,
   Gender varchar(20),
   height float(5,3),
   house_no int(20),
   city varchar(50),
   street_no int(10),
   birth_mark varchar(50),
   Ph_no int(20),
   primary key(criminal_id)
);

create table Crime(
   Crime_id int(10),
   crime_name varchar(50),
   Crime_location varchar(100),
   Category varchar(100),
   primary key(Crime_id)
);

create table Punishment(
   Punishment_id int(10),
   Type varchar (100),
   court_status varchar(100),
   primary key (Punishment_id)
);

create table Dealing_Police_Station (
  Ps_id int(10),
  Ps_name varchar(100),
  Ps_address varchar(200),
  Landline varchar(20),
  primary key (Ps_id)
);

create table Investigation_officer(
   officer_id int(10),
   Lname varchar(50),
   Fname varchar(50),
   Officer_rank varchar(50),
   ph_no varchar(20),
   primary key(officer_id)
);

create table Prison(
  Prison_id int(10),
  Prison_name varchar(50),
  P_address varchar (50),
  Landline varchar(20),
  Primary key (Prison_id)
);

create table court_status(
    Court_id int(10),
    Court_type varchar(50),
    judge_id int(10) unique,
    judge_name varchar(50),
    C_address varchar(100),    
    Primary key(Court_id)
);


