<?php
$p= $_POST['p'];
$q= $_POST['q'];
$r= $_POST['r'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "CRIMINAL_RECORD_DB";

// Create connection
$conn = new mysqli($servername, $username,'',$dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
{ 
echo "Connected successfully";
}

$q="INSERT INTO punishment VALUES('$p','$q','$r')";
if ($conn->query($q) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error in criminal: " . $q . "<br>" . $conn->error;
}
?>