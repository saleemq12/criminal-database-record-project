<?php
$ah= $_POST['ah'];
$ai= $_POST['ai'];
$aj= $_POST['aj'];
$ak= $_POST['ak'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "CRIMINAL_RECORD_DB";
// Create connection
$conn = new mysqli($servername, $username,'',$dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
{ 
echo "Connected successfully";
}

$q="INSERT INTO prison VALUES('$ah','$ai','$aj','$ak')";
if ($conn->query($q) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error in court: " . $q . "<br>" . $conn->error;
}
?>