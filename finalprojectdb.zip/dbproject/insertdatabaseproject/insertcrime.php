<?php
$l= $_POST['l'];
$m= $_POST['m'];
$n= $_POST['n'];
$o= $_POST['o'];
$p= $_POST['p'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "CRIMINAL_RECORD_DB";
$conn = new mysqli($servername, $username,'',$dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
{ 
echo "Connected successfully";
}
$q="INSERT INTO crime VALUES('$l','$m','$n','$o','$p')";
if ($conn->query($q) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error in crime : " . $q . "<br>" . $conn->error;
}
?>