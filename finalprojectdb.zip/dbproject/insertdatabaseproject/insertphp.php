<?php
$a= $_POST['a'];
$b= $_POST['b'];
$c= $_POST['c'];
$d= $_POST['d'];
$e= $_POST['e'];
$f= $_POST['f'];
$g= $_POST['g'];
$h= $_POST['h'];
$i= $_POST['i'];
$j= $_POST['j'];
$k= $_POST['k'];
$l= $_POST['l'];
$m= $_POST['m'];
$n= $_POST['n'];
$o= $_POST['o'];
$p= $_POST['p'];
$q= $_POST['q'];
$r= $_POST['r'];
$s= $_POST['s'];
$t= $_POST['t'];
$u= $_POST['u'];
$v= $_POST['v'];
$w= $_POST['w'];
$x= $_POST['x'];
$y= $_POST['y'];
$z= $_POST['z'];
$ab= $_POST['ab'];
$ac= $_POST['ac'];
$ad= $_POST['ad'];
$ae= $_POST['ae'];
$af= $_POST['af'];
$ag= $_POST['ag'];
$ah= $_POST['ah'];
$ai= $_POST['ai'];
$aj= $_POST['aj'];
$ak= $_POST['ak'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "CRIMINAL_RECORD_DB";

// Create connection
$conn = new mysqli($servername, $username,'',$dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
{ 
echo "Connected successfully";
}

$q="INSERT INTO criminal VALUES('$a','$b','$c','$d','$e','$f','$g','$h','$i','$j','$k')";
if ($conn->query($q) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error in criminal: " . $q . "<br>" . $conn->error;
}

$q="INSERT INTO crime VALUES('$l','$m','$n','$o')";
if ($conn->query($q) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error in crime : " . $q . "<br>" . $conn->error;
}

$q="INSERT INTO Punishment VALUES('$p','$q','$r')";
if ($conn->query($q) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error in punishment: " . $q . "<br>" . $conn->error;
}

$q="INSERT INTO court_status VALUES('$s','$t','$u','$v','$w')";
if ($conn->query($q) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error in court_status: " . $q . "<br>" . $conn->error;
}

$q="INSERT INTO dealing_police_station VALUES('$x','$y','$z','$ab')";
if ($conn->query($q) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error in d_ps: " . $q . "<br>" . $conn->error;
}

$q="INSERT INTO investigation_officer VALUES('$ac','$ad','$ae','$af','$ag')";
if ($conn->query($q) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error in officer: " . $q . "<br>" . $conn->error;
}

$q="INSERT INTO Prison VALUES('$ah','$ai','$aj','$ak')";


if ($conn->query($q) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error in prison: " . $q . "<br>" . $conn->error;
}

?>