<?php
$s= $_POST['s'];
$t= $_POST['t'];
$u= $_POST['u'];
$v= $_POST['v'];
$w= $_POST['w'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "CRIMINAL_RECORD_DB";

// Create connection
$conn = new mysqli($servername, $username,'',$dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
{ 
echo "Connected successfully";
}

$q="INSERT INTO court_status VALUES('$s','$t','$u','$v','$w')";
if ($conn->query($q) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error in court: " . $q . "<br>" . $conn->error;
}
?>