<?php
$ac= $_POST['ac'];
$ad= $_POST['ad'];
$ae= $_POST['ae'];
$af= $_POST['af'];
$ag= $_POST['ag'];
$x= $_POST['x'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "CRIMINAL_RECORD_DB";

// Create connection
$conn = new mysqli($servername, $username,'',$dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
{ 
echo "Connected successfully";
}

$q="INSERT INTO investigation_officer VALUES('$ac','$ad','$ae','$af','$ag','$x')";
if ($conn->query($q) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error in court: " . $q . "<br>" . $conn->error;
}
?>