<?php
$x= $_POST['x'];
$y= $_POST['y'];
$z= $_POST['z'];
$ab= $_POST['ab'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "CRIMINAL_RECORD_DB";
// Create connection
$conn = new mysqli($servername, $username,'',$dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
{ 
echo "Connected successfully";
}
$q="INSERT INTO dealing_police_station VALUES('$x','$y','$z','$ab')";
if ($conn->query($q) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error in court: " . $q . "<br>" . $conn->error;
}
?>